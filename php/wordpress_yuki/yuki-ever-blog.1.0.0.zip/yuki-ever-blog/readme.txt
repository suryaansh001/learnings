=== Yuki Ever Blog ===
Contributors: wpmoose
Author: WP Moose
Requires at least: WordPress 5.2+
Tested up to: WordPress 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Multi-purpose and Customizable Free WordPress Blog Theme. based on the modern and highly customizable Yuki multipurpose WordPress theme. You can fully customize your site with rich customize options. It is perfect for personal bloggers and content publishers.

== Copyright ==

Yuki Ever Blog is licensed under the GNU General Public License v2 or later

More details [here](http://www.gnu.org/licenses/gpl-2.0.html).

== Images ==

Image for theme screenshot and assets

License: CC0 Public Domain

https://pxhere.com/en/photo/724127
https://pxhere.com/en/photo/1049920
https://www.rawpixel.com/image/5927176
https://www.rawpixel.com/image/6169189

== Changelog ==

= 1.0.0 =

* Hello World!
